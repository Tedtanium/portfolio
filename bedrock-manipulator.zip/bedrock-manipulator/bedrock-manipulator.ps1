﻿ # _______          __                 __        ___ ___             __             __       __              #
 #|   _   .-----.--|  .----.-----.----|  |--.   |   Y   .---.-.-----|__.-----.--.--|  .---.-|  |_.-----.----.#
 #|.  1   |  -__|  _  |   _|  _  |  __|    <    |.      |  _  |     |  |  _  |  |  |  |  _  |   _|  _  |   _|#
 #|.  _   |_____|_____|__| |_____|____|__|__|   |. \_/  |___._|__|__|__|   __|_____|__|___._|____|_____|__|  #
 #|:  1    \                                    |:  |   |              |__|                                  #
 #|::.. .  /                                    |::.|:. |                                                    #
 #`-------'                                     `--- ---'                                                    #

# If using the SSH feature, only use this if you're nearly certain your processes will work on the target machine(s) and not break anything! #
# Measure twice before you cut! #


#### Variable Initialization ###
Set-Location $PSScriptRoot
$scpOrSSH = [ordered]@{"1" = "SSH"; "2" = "SCP"; "3" = "Automatically accept host keys"; "4" = "Open interactive PuTTY windows for each host"; "5" = "Create hostname dictionary using ips.txt"} ; $fileDict = [ordered]@{}
$fileNum = 0
$progress = 0 ; $progressTotal = (Get-Content ".\ips.txt").Length
$ipThird = 193 ; $ipFourth = 2
################################

### Error Suppression ###
#To work properly, this script has to suppress errors from PowerShell. This stores the old value and will restore it at script's end.
$PlacetoStoreErrorActionPreference = $ErrorActionPreference
$ErrorActionPreference = 'silentlycontinue'
#$ErrorActionPreference = 'continue'
#########################

######### Wrap-Up #######
# Executed when the script is completed. 
Function Wrap-Up($selectedFile, $startTime) {
$ErrorActionPreference = $PlacetoStoreErrorActionPreference
if (Test-Path -Path ".\filedump.txt" -PathType Leaf) {
    Remove-Item ".\filedump.txt"
    }
Remove-Job *
Read-Host -Prompt "All tasks complete! Press Enter to exit"
Exit
}
#########################

###### IP Address Printer ######
Function IPPrinter {
    #Prints out target IP addresses for the user to look over and confirm.
    foreach($ip in Get-Content ".\ips.txt") {
        if ($ip -match '^10\.') {
            #$hostTarget = Select-String -Path ".\ips.txt" -Pattern $ip -Context 2, 3
            #if ($hostTarget -eq $null) {
            #    $hostTarget = "not in dictionary)" }
            echo $ip
            #echo "$ip ($hostTarget)"
        }
    }
}
################################

########## Dictionary Builder #################################
function PSDictBuild {
    $progressTotal = 745
    $progressCompletePercent = 0
    echo "Building dictionary, please wait..."
    # Wipes the contents of the Dictionary file before use.
    Clear-Content ".\data\Dictionary.txt"
    ### TODO: Create something that can loop through all IP addresses of the environment.
    while($ipFourth -ne 127 -or $ipThird -ne 196) {
           Write-Progress -Activity "Building Dictionary..." -Status "Progress: ($progress/$progressTotal), last completed: 10.65.$ipThird.$ipFourth" -PercentComplete $progressCompletePercent
            # Tries the IP via Plink - if it can't connect, it doesn't add an entry to Dictionary.txt. 
           $hostname = echo y | plink -ssh -pw $pw $user@"10.65.$ipThird.$ipFourth" "hostname" 2> $null 4> $null
           #echo $hostname
           if ($hostname -ne $null) {
               echo "10.65.$ipThird.$ipFourth `= $hostname" >> ".\data\Dictionary.txt" }
            #Write-Host 10.65.$ipThird.$ipFourth

           # If block goes here for bounds manipulation.
           if ($ipFourth -eq 254) {
                $ipFourth = 1 ; $ipThird ++}
            if ($ipFourth -eq 1 -and $ipThird -eq 195) {
            $ipFourth = 64}
            if ($ipFourth -eq 190 -and $ipThird -eq 195) {
            $ipFourth = 1 ; $ipThird = 196} 
            # If blocks to catch network edges.
            if ($ipFourth -eq 62 -and $ipThird -eq 193) {
            $ipFourth = $ipFourth + 2 }
            if ($ipFourth -eq 126 -and $ipThird -eq 193) {
            $ipFourth = $ipFourth + 2 }
            if ($ipFourth -eq 190 -and $ipThird -eq 193) {
            $ipFourth = $ipFourth + 2 }
            if ($ipFourth -eq 126 -and $ipThird -eq 194) {
            $ipFourth = $ipFourth + 2 }
            if ($ipFourth -eq 126 -and $ipThird -eq 195) {
            $ipFourth = $ipFourth + 2 }
            if ($ipFourth -eq 190 -and $ipThird -eq 195) {
            $ipFourth = $ipFourth + 2 }
            if ($ipFourth -eq 62 -and $ipThird -eq 196) {
            $ipFourth = $ipFourth + 2 }

            # Increments $ipFourth by 1.
            $ipFourth ++
           # Clears hostname, adds to progress, and recalculates $progressCompletePercent.
           $hostname = "" ; $progress ++ ; $progressCompletePercent = ($progress/$progressTotal) * 100
        }
        Write-Progress -Activity "Building Dictionary..." -Status "Progress: Complete!" -PercentComplete 100
        Wrap-Up
    }
###############################################################
##### SCP #####################################################
Function PSforSCP {
    #Asks the user if they want to push or pull.
    while (($pushOrPull -ne 1) -and ($pushOrPull -ne 2)) {
    $pushOrPull = Read-Host -Prompt "Do you want to push a file to target machines or pull it from them? [1 = Push, 2 = Pull]" }
    #Handles push cases.
    if ($pushOrPull -eq 1) {
        #Gets what is in the packages folder and pulls it into a list/dictionary/Hashtable.
        $fileList = (Get-ChildItem ".\packages\").Name
        echo $fileList > ".\filedump.txt"

        foreach($line in Get-Content ".\filedump.txt") {
            $fileNum ++
            #Adds the entry to the hash table $fileDict.
            $fileDict["$fileNum"] = $line
            }
        $fileDict
        $selectedFile = Read-Host -Prompt 'Enter the file number you wish to upload'
        $selectedFile = $fileDict.$selectedFile
        $filePath = $PSScriptRoot + '\packages\' + $selectedFile
        $fileSCPDestination = Read-Host -Prompt "Where would you like the file to go? [Leave blank for /home/$user/; if chosen directory requires elevated privileges this will not succeed.]"
        if ($fileSCPDestination = "") {
            $fileSCPDestination = "/home/${user}" }
            
        echo ""
        echo "This will upload $selectedFile to the following hosts:"
        #Prints out target IP addresses for the user to look over and confirm.
        IPPrinter
        echo ""
        Read-Host -Prompt "Do you wish to continue? [Enter for yes, CTRL-C to exit]"
        $startTime = Get-Date -Format "MM-dd-yyyy_HH-mm"
        foreach($ip in Get-Content ".\ips.txt") {
            # The below makes the first line effectively ignored by only doing follow-up steps for IP addresses that start with "10.". 
            if ($ip -match '^10\.') {
                echo "Attempting to SCP to $ip..."
                # The following otherwise uses PuTTY's SCP function to zoop the target file(s) up to the user's home directory.
                pscp -pw ${pw} -r "$filePath" ${user}@${ip}:${fileSCPDestination}
                echo "Finished with $ip!"
                }
            }
        }
    if ($pushOrPull -eq 2) {
        # Asks the user for a target directory/file to pull, stored under $fileSCPDestination.
        $fileSCPDestination = Read-Host -Prompt "Where would you like to get the file/directory from? [Leave blank to pull all contents of /home/$user/]"
        if ($fileSCPDestination -eq " ") {
            $fileSCPDestination = "/home/${user}/" 
            $fileSCPPull = '*'
            $dirName = "home"}

        # Regex goes here to separate file from filepath. "([^\/]+).$" gets everything after the last /.        
        if (-not($fileSCPDestination -eq "/home/${user}/")) {
            $SCPRegex = '([^\/]+).$'
            $fileSCPDestination -match $SCPRegex
            $fileSCPPull = $Matches[0] 
            $dirName = $Matches[0]}
            echo $fileSCPPull
        # Gets user confirmation for the file/directory to be pulled.
        echo "This will pull the file/directory of $fileSCPDestination from the following hosts:"
        IPPrinter
        echo ""
        Read-Host -Prompt "Do you wish to continue? [Enter for yes, CTRL-C to exit]"
        # Starts a foreach IP line.
        foreach($ip in Get-Content ".\ips.txt") {
            if ($ip -match '^10\.') {
                if (-not($fileSCPDestination -eq "/home/$user/")) {
                    echo "Copying target item/directory $fileSCPPull into /home/$user and changing ownership of the copied file..."
                    # Starts by SSHing into each machine and using `sudo -S` to copy each of the files to /home/$user; then chowns the copied item and everything in it to the user, assuring it can be copied down.
                    echo $pw | plink -ssh -pw $pw $user@$ip "sudo -S cp -r $fileSCPDestination /home/${user}"
                    echo $pw | plink -ssh -pw $pw $user@$ip "sudo -S chown ${user}:${user} /home/${user}/${fileSCPPull}"
                    }

                echo "Attempting to SCP from $ip..."
                # Performs SCP to bring it down to ".\scp-received\". 
                mkdir "${PSScriptRoot}\scp-received\${ip}-${dirName}\"
                pscp -pw ${pw} -r ${user}@${ip}:"/home/${user}/${fileSCPPull}" "${PSScriptRoot}\scp-received\${ip}-${dirName}\${dirName}" 
                echo "Removing the file from /home/ directory..."
                echo $pw | plink -ssh -pw $pw $user@$ip "rm -rf /home/${user}/${fileSCPPull}"
                echo "Finished with $ip!"
                
            }
        }
        
    echo "All done. The copied files should be available at ${PSScriptRoot}\scp-received\<ip>\${dirName}\."
    }
    Wrap-Up
}

############# Host Key Acceptance Function ####################
# If a host key isn't accepted into PuTTY, it won't allow the connection to happen. This must happen on a per-connection basis and workarounds have to be done to accept them automatically; thus this option!
Function PSforHostKeyAcceptance {
    echo "This will get host keys automatically accepted for the following IP addresses:"
    echo ""
    #Prints out target IP Addresses.
    IPPrinter
    echo ""
    Read-Host -Prompt "Do you wish you continue? [Enter for yes, CTRL-C to exit]"
    foreach($ip in Get-Content ".\ips.txt") {
    # The below makes the first line effectively ignored by only doing follow-up steps for IP addresses that start with "10.". 
    if ($ip -match '^10\.') {
        echo "SSHing to $ip..."
        echo y | plink -ssh -pw $pw $user@$ip "exit"
        echo "Finished with $ip!"
        }
    }
    echo "All host keys should now be accepted; returning to system menu..."
    echo ""
    PSforSysMenu
}
###############################################################
############ SSH (synchronous) ################################
Function PSforSSHSynchronous {


    #Gets what is in the runbooks folder and pulls it into a list/dictionary/Hashtable.
    $fileList = (Get-ChildItem ".\runbooks\").Name
    echo $fileList > ".\filedump.txt"

    foreach($line in Get-Content ".\filedump.txt") {
        $fileNum ++
        #Adds the entry to the hash table $fileDict.
        $fileDict["$fileNum"] = $line
        }
    $fileDict
    $selectedFile = Read-Host -Prompt 'Enter runbook number'
    $selectedFile = $fileDict.$selectedFile
    $filePath = $PSScriptRoot + '\runbooks\' + $selectedFile

    echo ""
    ##### User Prompted Confirmation #####
    # Checks for a period in the filename, denoting some form of file extension.
    echo $filePath
    echo "You are about to execute the following runbook:"
    echo "============================"
    type $filePath
    echo "============================"
    echo ""
    echo "Hosts:"
    echo "============================"
    IPPrinter
    echo "============================"
    echo ""
    Read-Host -Prompt "Do you wish to continue? [Enter for yes, CTRL-C to exit]"
    $startTime = Get-Date -Format "MM-dd-yyyy_HH-mm"
    foreach($ip in Get-Content ".\ips.txt") {
        # The below makes the first line in "ips.txt" effectively ignored by only doing follow-up steps for IP addresses (or numbers). 
        if ($ip -match '^10\.') {
            #$hostTarget = Select-String -Path ".\ips.txt" -Pattern $ip -Context 2, 3
            #if ($hostTarget -eq $null) {
                #$hostTarget = "not in dictionary)" }
            Write-Progress -Activity "Performing batch SSH..." -Status "Progress: ($progress/$progressTotal)" -PercentComplete $progressCompletePercent
            echo "### Attempting to SSH to $ip... ####" | Tee-Object ".\logs\${selectedFile}-${startTime}.txt" -Append
            # The following otherwise uses PuTTY's autocommand function to execute the commands in the appointed file starting in the user's home directory.
            echo $pw | plink -ssh -m $filepath -pw $pw $user@$ip | Tee-Object ".\logs\${selectedFile}-${startTime}.txt" -Append
            echo "######## Finished with $ip! ########" | Tee-Object ".\logs\${selectedFile}-${startTime}.txt" -Append
            echo "##############################################" | Tee-Object ".\logs\${selectedFile}-${startTime}.txt" -Append
            $progress ++ ; $progressCompletePercent = ($progress/$progressTotal) * 100
        }
    }
    echo "All tasks complete!" >> ".\logs\${selectedFile}-${startTime}.txt"
    echo "Logs for the operation can be found at .\logs\${selectedFile}-${startTime}.txt."
    Wrap-Up
}
###############################################################
############ PuTTY Window Launcher ############################
Function PSforPuTTYWindowLauncher {
    echo "This will start interactive PuTTY sessions for the following hosts:"
    echo ""
    echo "============================"
    IPPrinter
    echo "============================"
    echo ""
    Read-Host -Prompt "Do you wish to continue? [Enter for yes, CTRL-C to exit"
    foreach($ip in Get-Content ".\ips.txt") {
        # The below makes the first line in "ips.txt" effectively ignored by only doing follow-up steps for IP addresses (or numbers). 
        if ($ip -match '^10\.') {
            putty.exe -ssh $user@$ip -pw $pw
            }
        }
    Wrap-Up
}

###############################################################
############ Main function ####################################

######## Auth Block #########
    $user = Read-Host -Prompt 'Input Username'
    #Stores password in hash securely, then makes it accessible to the script to input as $pw. Safe for screenshares!
    $securedValue = Read-Host -AsSecureString 'Input PW'
    $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($securedValue)
    $pw = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)


###############################################################
####### System Menu Function ##################################

Function PSforSysMenu {
    echo " # _______          __                 __        ___ ___             __             __       __              #"
    echo " #|   _   .-----.--|  .----.-----.----|  |--.   |   Y   .---.-.-----|__.-----.--.--|  .---.-|  |_.-----.----.#"
    echo " #|.  1   |  -__|  _  |   _|  _  |  __|    <    |.      |  _  |     |  |  _  |  |  |  |  _  |   _|  _  |   _|#"
    echo " #|.  _   |_____|_____|__| |_____|____|__|__|   |. \_/  |___._|__|__|__|   __|_____|__|___._|____|_____|__|  #"
    echo " #|:  1    \                                    |:  |   |              |__|                                  #"
    echo " #|::.. .  /                                    |::.|:. |                                                    #"
    echo " # `-------'                                      `--- ---'                                                    #"
    echo ""
    echo "######## System Menu ########"
    $scpOrSSH
    echo ""
    $choice = Read-Host -Prompt "Make a choice [num]"
    echo ""
    if ($choice -eq "1") {
        PSforSSHSynchronous
        }
    if ($choice -eq "2") {
        PSforSCP
        }
    if ($choice -eq "3") {
        PSforHostKeyAcceptance
        }
    if ($choice -eq "4") {
        PSforPuTTYWindowLauncher
        }
    if ($choice -eq "5") {
        PSDictBuild
        }
    }
###############################################################
###############################################################

PSforSysMenu