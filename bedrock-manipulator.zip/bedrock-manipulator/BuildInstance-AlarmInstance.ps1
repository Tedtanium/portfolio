﻿########### Variable Init #########
$CloudwatchQuestion = ""
###################################
####### Supporting Functions ######
Function CWConfigSelector {

    echo ""
    echo "This will create a link to an existing CW log group. Make sure it's been created first!"
    #Gets what is in the cwagent configs folder and pulls it into a list/dictionary/Hashtable.
    $fileList = (Get-ChildItem ".\cwagent configs\").Name
    echo $fileList > ".\filedump.txt"

    foreach($line in Get-Content ".\filedump.txt") {
        $fileNum ++
        #Adds the entry to the hash table $fileDict.
        $fileDict["$fileNum"] = $line
        }
    $fileDict
    $selectedFile = Read-Host -Prompt 'Enter the number corresponding to the config you want to push:'
    $selectedFile = $fileDict.$selectedFile
    $filePath = $PSScriptRoot + '\cwagent configs\' + $selectedFile

    
    Read-Host "This will send log files to the $selectedFile CW log group. Make sure it's been created first in AWS! [Enter to continue, or CTRL-C to quit]"
}








###################################

######## Main Functions ###########

Function BuildAnInstance {
    
    echo ""
    Read-Host "You are about to build one or more instances. Would you like to continue? [Enter for yes, CTRL-C to exit]"


}

Function AlarmAnInstance {

    echo ""
    $CloudwatchQuestion = Read-Host "Do logs from this instance need to be pushed to Cloudwatch? [y for yes, enter for no]"
    if ($CloudwatchQuestion -match "y") {
        CWConfigBuilder
}