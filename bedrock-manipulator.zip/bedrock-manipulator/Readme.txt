 =============================================================================================================
|   _______          __                 __        ___ ___             __             __       __              |
|  |   _   .-----.--|  .----.-----.----|  |--.   |   Y   .---.-.-----|__.-----.--.--|  .---.-|  |_.-----.----.|
|  |.  1   |  -__|  _  |   _|  _  |  __|    <    |.      |  _  |     |  |  _  |  |  |  |  _  |   _|  _  |   _||
|  |.  _   |_____|_____|__| |_____|____|__|__|   |. \_/  |___._|__|__|__|   __|_____|__|___._|____|_____|__|  |
|  |:  1    \                                    |:  |   |              |__|                                  |
|  |::.. .  /                                    |::.|:. |                                                    |
|  `-------'                                     `--- ---'                                                    |
 =============================================================================================================                                                                                                           

This is a scriptlet that allows for custom SSH commands to be used in bulk, and also to be able to SCP things up to multiple destinations in a row. 


+==============+
|Prerequisites|
+==============+

Software prerequisites are PuTTY and PowerShell. 

Before running the script, check to make sure the target IP addresses in ips.txt are correct. If you are using SSH, make sure that the runbook .txt file you have in .\runbooks\ is good to go! It's fine if multiple are in there; you select one interactively in the script. Similarly, if you are using SCP to upload files, make sure that the file(s) you want to copy up are put in .\packages\. Again, it's fine if other things are in the folder as well; you will get to select which file you wish to upload at runtime!

+==============+
|Things to note|
+==============+

- While the script will prompt for your username and password, neither of these things are stored past script runtime. When the script's finished doing your bidding, it won't remember a thing. The password is securely stored as the script runs as well; input is also hidden, making this script safe to run during screenshares.
- Outside of a confirmation or two, this script has no training wheels nor error correction. Not that it likely needs saying, but be careful with bulk SSH, especially in production!
- This executes commands/uploads to one destination at a time. While this is done very rapidly, any process that needs to be done simultaneously will need to be done manually until Ted can figure out how to make SSH jobs work asynchronously (probably not hard, but requires some time investment).
- Logs will be written to ".\logs\", and will be timestamped in name by both the beginning of the operation and the name of the playbook being run.

+==========+
|The How-To|
+==========+

First, run the Powershell script, bedrock-manipulator.ps1. This is done by right-clicking it and selecting "Run with PowerShell". After entering username and PW, you will be prompted to select SSH or SCP by entering either 1 or 2, with an automatic host key acceptor as option #3. If there's a chance you haven't connected to an instance in a long time, you should select 3 before you go about any other operations. Accepted host keys are required for automation!

If you enter 1, the script will look through and display everything in the .\runbooks\ folder, and give you the option to pick a runbook you've created to execute on every machine in ips.txt. If you enter 2, basically same thing, except it will search the .\packages\ folder and give you options from there.

If SSHing, the script will next write out every command in the runbook as well as every IP address in ips.txt and ask you to confirm whether or not you wish to go ahead with it. If SCPing, it will ask for confirmation that you want to send <filename> to <ip address(es)>. Hitting enter in both scenarios will go ahead and start the process.

The script will begin using SSH commands sequentially if chosen, to machines in the order they're written in in ips.txt; after it finishes with one machine, it will start the process on the next. 

If SCP was selected, it will basically do this, but will also prompt you to determine first whether you want to push (upload) or pull (download) a given file from each host IP. If you push, it will ask you where you want to upload the file to (note: if the destination requires elevated privileges, this will fail). If you pull, it will ask you where you want to pull from, by default pulling the complete contents of your /home directory. It does this by SSHing into each device, copying the file to your home directory, and then chowning the file over to you before SCPing it down; it will then delete this copy of the file from your /home directory.

+=================+
|What's a runbook?|
+=================+

A runbook is simply a .txt file with SSH (bash) commands put in it. They will run in sequence, but have little level of feedback into the console when executed; it is recommended to add echo statements for debug/relief purposes (e.g. to let you know something fired successfully). Commands such as "ls -l" also fire properly and give feedback. Echo statements should be properly reflected in logs as well. To show user input for an echo statement, it's recommended that you begin each statement with "echo >" to better be able to see inputs in the log.

Any runbooks *must* have a dummy line at the bottom (e.g. # End of file #), as for some reason, it won't read the last line in a runbook! This ensures that all functional lines are read and executed.

Any runbooks that have the "sudo" command in it must have "sudo -S". This is to force the password prompt that comes afterward to be able to be handled by the password argument automatically piped to PuTTY.