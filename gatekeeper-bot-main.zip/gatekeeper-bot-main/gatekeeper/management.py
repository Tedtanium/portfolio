import os
import shutil
import time
import asyncio
import datetime
import psutil
from rcon import Client

currentGame = 'Minecraft'
serverStatus = 'Down'
ipaddr = '127.0.0.1'
port = 27020
passwod = 'REDACTED'
lastSave = -1
startHour = datetime.time(5)
endHour = datetime.time(23)


# Unique to Medieval Madness #
dictPath = "REDACTED\\userdict.txt"
savePath = "REDACTED\\player-save-spillover"
activeSavePath = "REDACTED\\a-fabulous-place\playerdata"
        
###################### Start Server #####################

async def bootServer(self, filepath):
    global currentGame
    os.startfile(filepath)
        
#########################################################

###################### Stop Server ######################

async def terminateServer():  
    global currentGame, serverStatus, ipaddr, port, passwod
    if currentGame == 'ARK':
        with Client(ipaddr, port, passwd=passwod) as client:
            client.run('DoExit')
        target = 'ShooterGameServer.exe'
        os.system('TASKKILL /IM ' + target)  
    if currentGame == 'Minecraft':
        with Client(ipaddr, port, passwd=passwod) as client:
            client.run('stop')
            await asyncio.sleep(20)
            os.system('TASKKILL /IM java.exe /F')

        


#########################################################

##############  Server exe is Running Test ##############

async def serverTest(self):
    global currentGame
    if currentGame == 'ARK':
        serverProcessExists = "ShooterGameServer.exe" in (p.name() for p in psutil.process_iter())
    if currentGame == 'Minecraft':
        serverProcessExists = "java.exe" in (p.name() for p in psutil.process_iter())
    return(serverProcessExists)
    
#########################################################

###################### Status Check #####################

async def serverStatusCheck(self, cmd):
# Instigates connection to RCON and tries to get a playercount; if this fails the server is still starting.
    global currentGame, serverStatus, ipaddr, port, passwod
    serverProcessExists = await serverTest(self)
    if serverProcessExists == True:
        try:
            with Client(ipaddr, port, passwd=passwod) as client:
                # If statement that catches worldsave command without polluting serverStatus.
                if cmd != 'listplayers' and cmd != 'list':
                    client.run(cmd)
                    return
                playersOnline = client.run(cmd)
                serverStatus = 'Up'
            if currentGame == 'ARK':
                if 'No Players Connected' in playersOnline:
                    playerCount = 0
                else: 
                    playerCount = (playersOnline).count('\n')
            if currentGame == 'Minecraft':
                if 'There are 0' in playersOnline:
                    playerCount = 0
                else:
                    playerCount = 1
        except:
        # If this is running and gives an error, the server is still going up. The player_count variable is dummied out for this instance.
            serverStatus = 'Starting'
            playerCount = -1
        await inactivityChecker(self, playerCount)
    else:
        serverStatus = 'Down'
    return(serverStatus)

#########################################################

#################### Inactivity Check ###################

async def inactivityChecker(self, playersOnline):
    if playersOnline == 0:
        self.inactivityTime += 60
    else:
        self.inactivityTime = 0
    if self.inactivityTime >= 8100:
        await logger(self, str('Server has been inactive for 90 minutes! Shutting it down...'))
        await terminateServer()
        self.inactivityTime = 0
    return

#########################################################

################## After-Hours Shutdown #################

async def afterHoursShutdown(self):
    global startHour, endHour
    nowHour = datetime.datetime.now().time()
    #Used when endHour is before midnight.
    if endHour < nowHour or nowHour < startHour:
    #Used when endHour is after midnight.
    #if endHour < nowHour and nowHour < startHour:
        os.system("shutdown /s /t 1")
    else:
        return

#########################################################

#################### Status Heartbeat ###################

async def statusHeartbeat(self):
    if self.oldStatus != self.serverStatus:
        await logger(self, 'Server state change: ' + self.oldStatus + ' -> ' + self.serverStatus)
        self.oldStatus = self.serverStatus
    if self.inactivityTime % 1800 == 0 and self.inactivityTime != 0 and self.serverStatus == 'Up':
        await logger(self, str(int(self.inactivityTime / 60)) + ' minutes have passed in inactivity.')

#########################################################


####################### Logger ##########################

async def logger(self, msg):
    # Logic that determines what file is to be opened and written to. Logs change on the daily.
    targetFile = str(datetime.date.today().year) + '-' + str(datetime.date.today().month) + '-' + str(datetime.date.today().day) + '-Gatekeeper-Log.txt'
    targetPath = ".\\logs\\"
    open(targetPath + targetFile, "a").writelines('[' + str(datetime.datetime.now().strftime("%H:%M:%S")) + '] - ' + msg + '\n')
    open(targetPath + targetFile).close()
    print('[' + str(datetime.datetime.now().strftime("%H:%M:%S")) + '] - ' + msg)

#########################################################

################### Dictionary Checker ##################

async def dictCheck(self, discordID):
    # This is used to verify a user is in the dictionary, simple as that.
    getUserCheck = await getUser(self, discordID) 
    if getUserCheck == False:
        return False
    else:
        return True

#########################################################

################# Get User (Dictionary) #################

async def getUser(self, discordID):
    # This is used to retrieve a user's UUID through their Discord user ID.
    with open(dictPath, "r") as userDict:
        for line in userDict:
            # Converts discord_id to a string from an integer so it can be searched in the dictionary.
            if str(discordID) in line:
                # Splits Discord username from UUID. The [1] in the array is just the UUID (discord_id,mc_uuid).
                split = (line.split(','))
                return split[1].strip()
        if split == "":
            return False

#########################################################

#################### Get User Saves #####################
async def getUserSaves(self, UUID):
    listofFiles = []
    saveFiles = os.listdir(path=savePath)
    for line in saveFiles:
        if str(UUID) in line:
            lineSplit = line.split("_")[0]
            listofFiles.append(lineSplit)
    return listofFiles

#########################################################

############## Argument Validity Checker ################
# Used to determine whether or not a file title is valid. 
async def argChecker(self, arg):
    if arg.isalnum() == True and len(arg) < 41:
        return True
    else:
        return

#########################################################

################## Check Online State ###################
# This checks the online status of a given player via polling all connected players with RCON.
async def isPlayerOnline(self, playerUUID):
    global currentGame, serverStatus, ipaddr, port, passwod
    try:
        with Client(ipaddr, port, passwd=passwod) as client:
            onlinePlayers = client.run('list uuids')
            if str(playerUUID) in onlinePlayers:
                return True
            else:
                return False
    # Except block triggers if RCON cannot connect to the server.
    except:
        return False
    
#########################################################

################## Check Active Save #################### 

async def checkActiveSave(self, UUID):
    activeSavePathWithUUID = str(activeSavePath + "\\" + UUID + ".dat")
    if os.path.isfile(activeSavePathWithUUID):
        return True
    else:
        return False

#########################################################

################## Check Archived Save ##################

async def checkArchivedSave(self, UUID, arg):
    listofFiles = await getUserSaves(self, UUID)
    if arg in listofFiles:
        return True
    else:
        return False

#########################################################

#################### Save Restore #######################

async def saveRestore(self, UUID, arg):
    archivedSavePathWithUUID = savePath + "\\" + arg + '_' + UUID + ".dat"
    activeSavePathWithUUID = activeSavePath + "\\" + UUID + ".dat"
    shutil.move(archivedSavePathWithUUID, activeSavePathWithUUID)

########################################################

#################### Save Archive ######################

async def saveArchive(self, UUID, arg):
    archivedSavePathWithUUID = savePath + "\\" + arg + '_' + UUID + ".dat"
    activeSavePathWithUUID = activeSavePath + "\\" + UUID + ".dat"
    shutil.move(activeSavePathWithUUID, archivedSavePathWithUUID)

########################################################

##################### Save Delete ######################

async def saveDelete(self, UUID, arg):
    archivedSavePathWithUUID = savePath + "\\" + arg + '_' + UUID + ".dat"
    os.remove(archivedSavePathWithUUID)

########################################################