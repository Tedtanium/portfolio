import discord
from discord.ext import commands, tasks
import os
import asyncio
import sys
import datetime
sys.path.append('REDACTED/Gatekeeper-Bot-main/gatekeeper')
import management as mgmt

client = commands.Bot(command_prefix = '>')

class ServerActions(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.currentGame = 'Minecraft'
### Used for Minecraft.
        self.filePath = 'REDACTED-FILEPATH'
        self.fileName = ''
### Used for ARK.
#        self.filePath = 'REDACTED-FILEPATH'
#        self.fileName = ''

    @commands.Cog.listener()
    async def on_ready(self):
        await mgmt.logger(self, 'Server Actions cog loaded.')

    @client.command()
    async def startServer(self, ctx, *arg):
        # Restricts bot usage to specific channels. Second one is test channel!
        if ctx.message.channel.id == REDACTED or ctx.message.channel.id == REDACTED: 
            #Tests to see if the server's already up; if it is it won't try to run another instance of it.
            serverTest = await mgmt.serverTest(self)
            if serverTest == True:
                await ctx.message.add_reaction('❌')
                await ctx.message.channel.send('Nope, I can\'t do that! The gate is already open!')
                return        
            await mgmt.logger(self, 'Starting server via command sent from user ' + str(ctx.message.author) + '!')
            await mgmt.bootServer(self, self.filePath)
            await ctx.message.add_reaction('✅')
            mgmt.serverStatus = 'Starting'
            await asyncio.sleep(5)
            serverTest = await mgmt.serverTest(self)
            if serverTest == True:
                await ctx.message.channel.send('Starting the server...')
                # Loop that lasts until the server is fully up or is down.
                while mgmt.serverStatus != 'Up':
                    await asyncio.sleep(10)
            # Gives a mention to the user that sent the command if they also included anything else in the command.
            if arg:
                await ctx.message.channel.send('I\'ve finished opening the gate, ' + ctx.message.author.mention + '. All who wish to head on through may do so.')
            else:
                await ctx.message.channel.send('The server is up! Proceed on in at your leisure.')
        return
        
            
    @client.command()
    async def stopServer(self, ctx):
        if ctx.message.channel.id == REDACTED or ctx.message.channel.id == REDACTED:
            serverTest = await mgmt.serverTest(self)
            if serverTest == True:
                await ctx.message.channel.send('Stopping the server...')
                await mgmt.terminateServer()
                await asyncio.sleep(5)
                serverTest = await mgmt.serverTest(self)
                await ctx.message.add_reaction('💾')
                await asyncio.sleep(5)
                if serverTest == False:
                    await mgmt.logger(self, 'Server successfully closed via command from user ' + str(ctx.message.author) + '!')
                    await ctx.message.add_reaction('🛑')
                else:
                    await ctx.message.channel.send('The gate...didn\'t close. Something\'s wrong.')
                    await ctx.message.add_reaction('❌')
            else:
                await ctx.message.channel.send('I can\'t do that. The gate is already closed!')
                await ctx.message.add_reaction('❌')
        return

    @client.command()
    async def debug(self, ctx):
        if ctx.message.channel.id == REDACTED or ctx.message.channel.id == REDACTED:
            print(ctx.message.author.id)
    
    @client.command()
    async def saveList(self, ctx):
            discordID = ctx.message.author.id
            # Checks to see if the player exists in the dictionary.
            checkForDictEntry = await mgmt.dictCheck(self, discordID)
            if checkForDictEntry == True:
                # Check to see if the player has any saves in the list.
                saveList = await mgmt.getUserSaves(self, await mgmt.getUser(self, discordID))
                if saveList == []:
                    await ctx.message.channel.send('You have no saves in the archive. To add one, try >saveArchive <save name> if you have logged onto the server before.')
                    await mgmt.logger(self, 'Save list operation attempted by user ' + str(ctx.message.author) + '- failed - they did not have any saves archived!')
                else: 
                    # List the player's files by the name they've been given by the player.
                    saveListResp = "You have the following save files available: \n" + str(saveList) + "\n \n To restore a save, try >saveRestore <saveName>, to delete a save, try >saveDelete <saveName>."
                    await ctx.message.channel.send(saveListResp)
                    await mgmt.logger(self, 'Save list operation attempted by user ' + str(ctx.message.author) + '- success')
            if checkForDictEntry == False:
                await ctx.message.add_reaction('❌')
                await ctx.message.channel.send('You are not registered for participation in save file management - to register, send Luthe a message with your Minecraft UUID (https://mcuuid.net/) and ask him to add you.')
                await mgmt.logger(self, 'Save list operation attempted by user ' + str(ctx.message.author) + '- they did not have a dictionary entry!')
                
    @client.command()
    async def saveArchive(self, ctx, arg):
        ## This needs to take an argument, figure out how.
        if ctx.message.channel.id == REDACTED or ctx.message.channel.id == REDACTED:
            # Checks to see if the player exists in the dictionary.
            checkForDictEntry = await mgmt.dictCheck(self, ctx.message.author.id)
            if checkForDictEntry == True:
                ## Check to see if the arg provided is one word, between 1 and 40 characters in length, and is fully alphanumeric.
                isArgValid = await mgmt.argChecker(self, arg)
                if isArgValid == True:
                    playerUUID = await mgmt.getUser(self, ctx.message.author.id)
                    ## Check to see if the player has a save in the MC directory.
                    activeSave = await mgmt.checkActiveSave(self, playerUUID)
                    if activeSave == True:
                        isPlayerOnline = await mgmt.isPlayerOnline(self, playerUUID)
                        if isPlayerOnline == False:
                            await mgmt.saveArchive(self, playerUUID, arg)
                            await ctx.message.add_reaction('✅')
                            await ctx.message.channel.send('All done. [\'' + str(arg) + '\'] has been archived. To restore it (or another) save, try >saveRestore <save>, or to make another file, log back into the server.')
                            await mgmt.logger(self, 'Save archive operation completed by ' + str(ctx.message.author) + '.')
                        if isPlayerOnline == True:
                            await ctx.message.add_reaction('❌')
                            await ctx.message.channel.send('It appears you are currently logged in on the server. Please log out and try again.')

                    ## Move the player's save from the MC directory to "./uuid/<arg>-<uuid>.dat" in the saves folder.
                    ## Report back to the player that the save has been successfully moved.
                    ## "To see your saves, type >saveList, to restore this save type >saveRestore <arg>. To start a new file, simply log into the server."
                    if activeSave == False:
                        await ctx.message.add_reaction('❌')
                        await ctx.message.channel.send('You do not have an active save loaded.')
                if isArgValid == False:
                        await ctx.message.add_reaction('❌')
                        await ctx.message.channel.send('Your save file name is invalid - only alphanumeric [a-z, 0-9] characters are accepted, up to 40 characters.')
            if checkForDictEntry == False:
                await ctx.message.add_reaction('❌')
                await ctx.message.channel.send('You are not registered for participation in save file management - to register, send Luthe a message with your Minecraft UUID (https://mcuuid.net/) and ask him to add you.')

    @client.command()
    async def saveRestore(self, ctx, arg):
        if ctx.message.channel.id == REDACTED or ctx.message.channel.id == REDACTED:
            # Checks to see if the player exists in the dictionary.
            checkForDictEntry = await mgmt.dictCheck(self, ctx.message.author.id)
            if checkForDictEntry == True:
                playerUUID = await mgmt.getUser(self, ctx.message.author.id)
                # Checks to make sure there is no current save in the MC directory. If there is, prompt the player to archive their save first and stop.
                activeSave = await mgmt.checkActiveSave(self, playerUUID)
                if activeSave == False:
                    # Checks to see if the arg matches up with any saves under their UUID folder. If not, stop and print list of saves.
                    archiveArgMatch = await mgmt.checkArchivedSave(self, playerUUID, str(arg))
                    if archiveArgMatch == True:
                    # Moves the file to the active saves folder, renaming it to "<uuid>.dat".
                        await mgmt.saveRestore(self, playerUUID, str(arg))
                        # Gives confirmation to the player that it's done.
                        await ctx.message.add_reaction('✅')
                        await ctx.message.channel.send('Done! [\'' + str(arg) + '\'] should now be loaded on the server, ready for your next login.')
                        await mgmt.logger(self, 'Save restore operation completed by ' + str(ctx.message.author) + '!')
                    if archiveArgMatch == False:
                        await ctx.message.channel.send('Your chosen filename does not match any archived files.')
                        # Tries to print the player's saves if they don't input the right save.
                        await self.saveList(ctx)
                if activeSave == True:
                    await ctx.message.add_reaction('❌')
                    await ctx.message.channel.send('You have an active file on the server already - you must archive it before you can restore another.')
            if checkForDictEntry == False:
                await ctx.message.add_reaction('❌')
                await ctx.message.channel.send('You are not registered for participation in save file management - to register, send Luthe a message with your Minecraft UUID (https://mcuuid.net/) and ask him to add you.')

    @client.command()
    async def saveDelete(self, ctx, arg):
        if ctx.message.channel.id == REDACTED or ctx.message.channel.id == REDACTED:
            # Checks to see if the player exists in the dictionary.
            checkForDictEntry = await mgmt.dictCheck(self, ctx.message.author.id)
            if checkForDictEntry == True:
                playerUUID = await mgmt.getUser(self, ctx.message.author.id)
                # Checks to see if the arg matches up with any saves under their UUID folder. If not, stop and print list of saves.
                archiveArgMatch = await mgmt.checkArchivedSave(self, playerUUID, str(arg))
                if archiveArgMatch == True:
                    ## Run the delete process for the select file.
                    await mgmt.saveDelete(self, playerUUID, arg)
                    await ctx.message.add_reaction('✅')
                    await ctx.message.channel.send('Save file [\'' + str(arg) + '\'] has been deleted.')
                if archiveArgMatch == False:
                    await ctx.message.channel.send('Your chosen filename does not match any archived files.')
                    # Tries to print the player's saves if they don't input the right save.
                    await self.saveList(ctx)
            if checkForDictEntry == False:
                await ctx.message.add_reaction('❌')
                await ctx.message.channel.send('You are not registered for participation in save file management - to register, send Luthe a message with your Minecraft UUID (https://mcuuid.net/) and ask him to add you.')





def setup(bot):
    bot.add_cog(ServerActions(bot))

